def increase_value(value: int, by_value: int = 5) -> int:
    """function to increase the value
    args:
        value (int): value
        by_value (int): to increase the value by
    """
    return value + by_value
