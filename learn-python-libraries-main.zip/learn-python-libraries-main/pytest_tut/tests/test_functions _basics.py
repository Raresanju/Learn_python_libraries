from src import functions


def test_main():
    assert 15 == functions.increase_value(10)
