**This repository is to learn about basic things to a repository like**
- Format using black
- Error free code using pylinit
- Documentation using pylint
- Configuation using toml or yaml
- Poetry to fix library version issues
- Test case by using pytest
- MakeFile to automate the small processes
- Versioning: on github and poetry

  
  **Youtube link to tutorials:** https://www.youtube.com/watch?v=EP2WNh9lw3g&list=PLQ_jKE7AEWt4p4Ej_FBEglc8hI-YeAl-Z
