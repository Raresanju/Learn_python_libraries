def function_to_print():
    """This function is to print new relase"""
    print("New Relase")
